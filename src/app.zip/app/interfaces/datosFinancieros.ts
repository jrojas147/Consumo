export interface DatosFinancieros {

    ActividadEconomica: Number;
    ActividadIndependiente?: Number;
    IngresoMensual: Number;

}