export interface DatosBasicos {
    Nombre: String;
    ValorVehiculo: Number;
    TipoDocumento: String;
    NumeroDocumento: String;
    Celular: String;
    CorreoPersonal: String;
    CuotaInicial: number;
    Plazo: number
}