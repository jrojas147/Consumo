export interface DatosVehiculo {
    Modelo: number;
    TipoVehiculo: number;
}