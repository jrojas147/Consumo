import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tipo-vehiculo',
  templateUrl: './tipo-vehiculo.component.html',
  styleUrls: ['./tipo-vehiculo.component.scss']
})
export class TipoVehiculoComponent implements OnInit {

  constructor() { }
  vehiculo = "carro";

  ngOnInit() {
  }

}
